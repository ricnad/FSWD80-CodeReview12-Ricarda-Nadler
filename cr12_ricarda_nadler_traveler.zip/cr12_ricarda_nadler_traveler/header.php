<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package nadler_foodblog
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link rel="stylesheet" href="http://localhost/travelblog/wp-content/themes/cr12_ricarda_nadler_traveler/style/style.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/css/bootstrap.min.css" integrity="sha384-SI27wrMjH3ZZ89r4o+fGIJtnzkAnFs3E4qz9DIYioCQ5l9Rd/7UAa8DHcaL8jkWt" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/js/bootstrap.min.js" integrity="sha384-3qaqj0lc6sV/qpzrc1N5DC6i1VRn/HyX4qdPaiEFbn54VjQBEU341pvjz7Dv3n6P" crossorigin="anonymous"></script>
	<link href="https://fonts.googleapis.com/css?family=Permanent+Marker|Ruthie|Solway&display=swap" rel="stylesheet">

	<?php wp_head(); ?>
</head>

<body>
  <nav class="navbar navbar-expand-lg" role="navigation" id="navi">
    <div class="container">
      <div class="row">
        <a class="navbar-brand" href="http://localhost/travelblog/">   
        <img src="http://localhost/travelblog/wp-content/themes/cr12_ricarda_nadler_traveler/img/plane_earth.png" alt="earth" style="height:80px"></a>
        <div>
          <h2><?php bloginfo('name'); ?></h2>
          <h4><?php bloginfo('description'); ?></h4>
        </div>
		    <?php
           wp_nav_menu( array(

               'theme_location'    => 'primary',
               'depth'             => 2, // 1 = no dropdowns, 2 = dropdown
               'container'         => 'div',
               'container_class'   => 'collapse navbar-collapse',
               'container_id'      => 'bs-example-navbar-collapse-1',
               'menu_class'        => 'nav navbar-nav',
               'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
               'walker'            => new WP_Bootstrap_Navwalker(),

           ) );

           ?>
	    </div>
    </div>
  </nav>


  
