<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package nadler_foodblog
 */

get_header();
?>
<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h2 class="display-3">Welcome to our Travel Agency</h2>
    <h4 class="lead">Get inspired by our blog-entries</h4>
  </div>
</div>
<div class="container">
  <div id="primary" class="content-area">
    <main id="main" class="site-main">
    <div class="row">
      <div class="col-sm-8 blog-main">
        <div class="row">
          <section class="showcase">
              <h2>At <?php bloginfo('name'); ?>...</h2>
              <p>Enjoy reading our newest posts about your favorite travel destinations. In case you need further information just drop us a note</p>
              <button type="button"><a href="http://localhost/travelblog/contact">Contact page</a></button>
          </section>
        </div>
        <div class="row">
            <?php if(have_posts()) :  ?>  <!--if there are any posts-->
            <!--Start the loop-->
            <?php while(have_posts()) : the_post(); ?><!--while there are posts, show the posts-->
                <div class="flip-card mr-4 ml-4 mb-2">
                  <div class="flip-card-inner">
                    <div class="flip-card-front">
                      <?php the_post_thumbnail('full'); ?>
                      <?php the_title('<h4 class="entry-title">','</h4>'); ?>
                    </div>
                <div class="flip-card-back">
                  <?php the_title('<h4 class="entry-title">','</h4>'); ?>
                  <p><?php nadler_foodblog_posted_on(); ?><br>
                     <?php nadler_foodblog_posted_by();?></p>
                  <?php the_excerpt('<p class="entry-content">','</p>'); ?>
                  <button type="button"><?php the_title('<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a>');?></button>
                </div>
              </div>
            </div>
            <?php endwhile; ?> <!--end the while loop-->

            <?php else : ?> <!--if there are no posts-->
              <p><?php__('No Posts Found'); ?></p>
          <?php endif; ?><!--endif-->
        </div>
      </div>

      <?php
      get_sidebar();?>
    </div>

    </main><!-- #main -->
  </div><!-- #primary -->
</div>
<?php
get_footer();